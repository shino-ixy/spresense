#ifndef _SAMPLE_EXTLIB_H_
#define _SAMPLE_EXTLIB_H_

int sample_extlib_add(int a, int b);

#endif /* _SAMPLE_EXTLIB_H_ */